
console.log("MapSnaps site loaded successfully.");
